#!/bin/sh
echo 'Configurando entorno Husky Linux'